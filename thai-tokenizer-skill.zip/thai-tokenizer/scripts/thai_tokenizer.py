#!/usr/bin/env python3
"""
thai_tokenizer.py
=================
Thai morpheme/compound tokenizer + compression analyzer.
Refactored from JeN's FINALFINAL4.py (May 2026) into a clean, importable
module with a JSON-friendly CLI so Claude can call it as a skill.

Two entry points:
  - Python:  from thai_tokenizer import analyze; analyze("ตระกูลชินวัตรถือหุ้นอะไรบ้าง")
  - CLI:     python thai_tokenizer.py "ตระกูลชินวัตรถือหุ้นอะไรบ้าง"
             python thai_tokenizer.py --json "..."      # structured output
             python thai_tokenizer.py --train-file seed.txt "..."

Design notes preserved from the original thesis (JeN, thai-ai-language-thesis):
  * Dual-mode tokenization: TRAIN = atomic morphemes, INFER = PMI-merged compounds
  * 5-layer word origin (Native / Sanskrit-Pali / English / Chinese / Hybrid)
  * Content-only reduction via 3-tier stopword filtering
  * PMI compound merging (threshold 3.0)

KNOWN BEHAVIOR (documented, not silently patched):
  The UNCUTTABLE set contains multi-morpheme conjunctions/question words
  (e.g. ที่ไหน). Segmentation may split these into parts (ที่ + ไหน) BEFORE
  the per-token UNCUTTABLE check runs. When that happens, a fragment like ที่
  can be removed by TIER1_CUT even though the whole word ที่ไหน was meant to
  survive. This affects a small number of compound conjunctions and slightly
  changes content-token counts. It is preserved as-is so compression ratios
  match JeN's validated figures (4.04x morpheme / 4.69x content). To change
  this, apply UNCUTTABLE matching on a sliding window BEFORE tier filtering.

INSTALL:  pip install pythainlp --break-system-packages
"""

import re
import sys
import math
import json
import argparse
from collections import Counter, defaultdict
from dataclasses import dataclass, field, asdict
from typing import List, Tuple, Dict

try:
    import pythainlp
    from pythainlp import pos_tag
    HAS_PYTHAINLP = True
except Exception:
    HAS_PYTHAINLP = False


# ============================================================================
# 1.  WORD ORIGIN — 5-layer detection
# ============================================================================

PALI_MARKERS = set('ณฑฒฐภศษฬ')

PALI_ROOTS = {
    'ภาษา', 'ราชา', 'กฎหมาย', 'ธรรม', 'ศาสนา', 'อักษร', 'ปัญญา', 'วิทยา',
    'มหา', 'อาจารย์', 'นิพพาน', 'กรรม', 'เหตุ', 'ผล', 'วิทยาลัย', 'มหาวิทยาลัย',
    'ประชาธิปไตย', 'สาธารณะ', 'ประสิทธิภาพ', 'อากาศยาน', 'สัตว์',
    'ชาติ', 'ศักดิ์', 'สิทธิ์', 'สมาชิก', 'ระเบียบ', 'รัฐธรรมนูญ', 'อนุ', 'ปฏิ',
    'วัฒนธรรม', 'เศรษฐกิจ', 'สังคม', 'การเมือง', 'ทหาร', 'ศาล', 'อำนาจ',
}

ENGLISH_LOANS = {
    'คอมพิวเตอร์', 'อินเทอร์เน็ต', 'ซอฟต์แวร์', 'ฮาร์ดแวร์', 'อีเมล',
    'เว็บไซต์', 'แอปพลิเคชัน', 'สมาร์ทโฟน', 'แท็บเล็ต', 'โทรศัพท์',
    'ช็อกโกแลต', 'กาแฟ', 'วีซ่า', 'แบงก์', 'มาร์เก็ต', 'บัส', 'แอร์', 'แฟน',
    'โปร', 'เกม', 'ทีม', 'กอล์ฟ', 'ฟุตบอล', 'บาสเก็ตบอล', 'เทนนิส',
    'ดอกเตอร์', 'โปรเฟสเซอร์', 'ออฟฟิศ', 'มอลล์', 'ช็อปปิง', 'ออนไลน์',
    'เซ็นเตอร์', 'ลิสต์', 'เรต', 'บล็อก', 'ไวรัส', 'แฮก', 'คลาวด์',
}

CHINESE_LOANS = {
    'เต้าหู้', 'ก๋วยเตี๋ยว', 'บะหมี่', 'ติ่มซำ', 'เจ๊ก', 'เซียน',
    'กวยจั๊บ', 'ซาลาเปา', 'ขนมจีน', 'เฮีย', 'เจ้', 'แป๊ะ', 'อาม่า', 'อากง',
}


def count_syllables(tok: str) -> int:
    vowels = set('ะาิีึืุูเแโใไ็ั')
    count, in_v = 0, False
    for ch in tok:
        if ch in vowels:
            if not in_v:
                count += 1
                in_v = True
        else:
            in_v = False
    return max(1, count)


def word_origin(tok: str) -> Tuple[str, str]:
    """Returns (origin_label, bridge_language)."""
    if tok in CHINESE_LOANS:
        return 'Chinese loan', 'Mandarin'
    if tok in ENGLISH_LOANS:
        return 'English loan', 'English'
    if tok in PALI_ROOTS:
        return 'Sanskrit/Pali', 'Sanskrit'
    if any(c in PALI_MARKERS for c in tok):
        return 'Sanskrit/Pali', 'Sanskrit'
    if '์' in tok and len(tok) >= 4:
        return 'English loan', 'English'
    if count_syllables(tok) >= 4:
        return 'Hybrid compound', 'Thai+Sanskrit'
    return 'Native Thai', ''


def is_thai(tok: str) -> bool:
    return any('฀' <= c <= '๿' for c in tok)


# ============================================================================
# 2.  REGISTER CLASSIFIER
# ============================================================================

def classify_register(tokens: List[str]) -> Tuple[str, Dict[str, int]]:
    counts = {'native': 0, 'sanskrit': 0, 'english': 0, 'chinese': 0, 'hybrid': 0}
    for tok in tokens:
        if not is_thai(tok):
            continue
        origin, _ = word_origin(tok)
        if 'Sanskrit' in origin:
            counts['sanskrit'] += 1
        elif 'English' in origin:
            counts['english'] += 1
        elif 'Chinese' in origin:
            counts['chinese'] += 1
        elif 'Hybrid' in origin:
            counts['hybrid'] += 1
        else:
            counts['native'] += 1

    total = sum(counts.values()) or 1
    pcts = {k: round(100 * v / total) for k, v in counts.items()}

    if pcts['sanskrit'] >= 40:
        label = 'FORMAL'
    elif pcts['english'] >= 30:
        label = 'TECHNICAL'
    elif pcts['native'] >= 70:
        label = 'COLLOQUIAL'
    else:
        label = 'MIXED'
    return label, pcts


# ============================================================================
# 3.  TEMPLATE REGISTRY
# ============================================================================

@dataclass
class Template:
    name: str
    keywords: List[str]
    description: str
    semantic_type: str


TEMPLATES = [
    Template('OWNERSHIP_QUERY', ['ถือหุ้น', 'ครอบครอง', 'เป็นเจ้าของ', 'เป็นของ'],
             '[ENTITY] ถือหุ้น/ครอบครอง [OBJECT]', 'ownership'),
    Template('DEFINITION_QUERY', ['หมายถึง', 'คือ', 'เรียกว่า', 'หมายความ'],
             '[CONCEPT] หมายถึง [DEFINITION]', 'definition'),
    Template('LOCATION_QUERY', ['อยู่ที่ไหน', 'ตั้งอยู่', 'อยู่ใน', 'อยู่ที่'],
             '[ENTITY] อยู่ที่ไหน', 'location'),
    Template('REASON_QUERY', ['ทำไม', 'เพราะอะไร', 'สาเหตุ', 'เหตุผล'],
             'ทำไม [ENTITY] ถึง [STATE]', 'causation'),
    Template('COMPARISON_QUERY', ['ต่างกัน', 'เหมือนกัน', 'เปรียบเทียบ'],
             '[X] กับ [Y] ต่างกันอย่างไร', 'comparison'),
    Template('PRICE_QUERY', ['ราคา', 'ค่า', 'ต้นทุน', 'มูลค่า'],
             'ราคา/มูลค่า ของ [ENTITY]', 'valuation'),
    Template('TIME_QUERY', ['เมื่อไร', 'เมื่อไหร่', 'วันที่', 'ปี'],
             '[EVENT] เกิดขึ้นเมื่อไร', 'temporal'),
    Template('CAPABILITY_QUERY', ['ทำได้', 'สามารถ', 'เป็นไปได้'],
             '[AGENT] สามารถ [ACTION] ได้ไหม', 'capability'),
    Template('PROCESS_QUERY', ['วิธี', 'ขั้นตอน', 'กระบวนการ', 'ทำยังไง', 'ทำอย่างไร'],
             'วิธีการ/ขั้นตอน ของ [PROCESS]', 'process'),
    Template('EXISTENCE_QUERY', ['มีไหม', 'มีหรือไม่', 'มีอะไร'],
             'มี [ENTITY] ไหม', 'existence'),
]


def match_templates(tokens: List[str]) -> List[Template]:
    token_set = set(tokens)
    return [t for t in TEMPLATES if any(kw in token_set for kw in t.keywords)]


# ============================================================================
# 4.  DUAL-MODE TOKENIZER  (TRAIN atomic vs INFER merged)
# ============================================================================

class DualModeTokenizer:
    """
    TRAIN mode: split to atomic morphemes so the model learns composition.
      เครื่องบิน -> [เครื่อง][บิน]
    INFER mode: merge high-PMI compounds for efficiency.
      เครื่องบิน -> [เครื่องบิน]
    """

    def __init__(self):
        self.morpheme_freq: Counter = Counter()
        self.bigram_freq: Counter = Counter()
        self.merge_rules: Dict = {}
        self.learned_compounds: set = set()
        self.trained = False

    def train(self, sentences: List[str]):
        for s in sentences:
            morphemes = [m for m in pythainlp.word_tokenize(s, engine='newmm')
                         if is_thai(m)]
            for m in morphemes:
                self.morpheme_freq[m] += 1
            for a, b in zip(morphemes, morphemes[1:]):
                self.bigram_freq[(a, b)] += 1

        total = sum(self.morpheme_freq.values()) or 1
        for (m1, m2), freq in self.bigram_freq.items():
            if freq < 2:
                continue
            p1 = self.morpheme_freq[m1] / total
            p2 = self.morpheme_freq[m2] / total
            pp = freq / total
            if p1 > 0 and p2 > 0 and pp > 0:
                pmi = math.log2(pp / (p1 * p2))
                if pmi > 3.0:
                    compound = m1 + m2
                    self.merge_rules[(m1, m2)] = compound
                    self.learned_compounds.add(compound)
        self.trained = True

    def tokenize_train(self, text: str) -> List[str]:
        return [m for m in pythainlp.word_tokenize(text, engine='newmm') if is_thai(m)]

    def tokenize_infer(self, text: str) -> List[str]:
        morphemes = self.tokenize_train(text)
        if not self.trained or not self.merge_rules:
            return morphemes
        merged, i = [], 0
        while i < len(morphemes):
            if i < len(morphemes) - 1 and (morphemes[i], morphemes[i + 1]) in self.merge_rules:
                merged.append(self.merge_rules[(morphemes[i], morphemes[i + 1])])
                i += 2
            else:
                merged.append(morphemes[i])
                i += 1
        return merged


# ============================================================================
# 5.  CONTENT-ONLY TOKENIZE  (3-tier stopword filtering)
# ============================================================================

UNCUTTABLE = {
    'อะไร', 'ใคร', 'ที่ไหน', 'เมื่อไร', 'ทำไม', 'อย่างไร',
    'ไม่', 'ไม่ได้', 'ไม่ใช่', 'ใช่',
    'ต้อง', 'ควร', 'อาจ', 'คง', 'น่าจะ', 'ห้าม',
    'ถ้า', 'หาก', 'แต่', 'เพราะ', 'จึง', 'แม้',
    'ยัง', 'เพิ่ง', 'เคย', 'ได้', 'โอเค', 'ตกลง',
}
TIER1_CUT = {
    'ครับ', 'ค่ะ', 'คะ', 'นะ', 'จ้า', 'จ๋า', 'จ๊า',
    'ไหม', 'มั้ย', 'ล่ะ', 'หรอ', 'เหรอ',
    'ๆ', 'และ', 'กับ', 'หรือ',
    'ใน', 'บน', 'ของ', 'จาก', 'ที่', 'โดย',
    'เป็น', 'คือ', 'บาง', 'หลาย', 'น้อย',
    'นั้น', 'เลย', 'ก็', 'แค่', 'ด้วย', 'ทั้ง', 'บ้าง',
}
TIER2_AUXILIARIES = {'ชอบ', 'อยาก', 'เคย', 'อาจ', 'คง'}
TIER3_KEEP_POS = {'NOUN', 'PROPN', 'VERB', 'ADJ', 'NUM'}
ADV_KEEP = {'มาก', 'น้อย', 'เร็ว', 'ช้า', 'ดี', 'เสมอ', 'บ่อย', 'ทันที'}


def thai_morpheme_tokenize(text: str) -> List[str]:
    return pythainlp.word_tokenize(text, engine='newmm')


def bpe_estimate(text: str) -> int:
    """Approx GPT-style BPE token count for Thai (bytes / 4.5)."""
    return max(1, round(len(text.encode('utf-8')) / 4.5))


def content_only_tokenize(text: str) -> List[str]:
    morphemes = thai_morpheme_tokenize(text)
    try:
        tagged = pos_tag(morphemes, engine='perceptron', corpus='pud')
    except Exception:
        tagged = [(m, 'UNKN') for m in morphemes]
    content = []
    for i, (token, pos) in enumerate(tagged):
        if not is_thai(token):
            continue
        if token in UNCUTTABLE:
            content.append(token)
            continue
        if token in TIER1_CUT:
            continue
        if token in TIER2_AUXILIARIES:
            if i < len(tagged) - 1 and tagged[i + 1][1] == 'VERB':
                continue
            content.append(token)
            continue
        if pos in TIER3_KEEP_POS:
            content.append(token)
            continue
        if pos == 'ADV' and token in ADV_KEEP:
            content.append(token)
            continue
    return content


# ============================================================================
# 6.  MULTILINGUAL BRIDGE
# ============================================================================

def multilingual_bridge(tokens: List[str]) -> Dict[str, List[str]]:
    bridges: Dict[str, List[str]] = defaultdict(list)
    for tok in tokens:
        if not is_thai(tok):
            continue
        _, bridge = word_origin(tok)
        if bridge:
            bridges[bridge].append(tok)
    return dict(bridges)


# ============================================================================
# 7.  DEFAULT SEED CORPUS  (bootstraps the PMI merger)
# ============================================================================

SEED = [
    "ตระกูลชินวัตรถือหุ้นอะไรบ้าง",
    "บริษัทเทสลาถือหุ้นบริษัทอะไรบ้าง",
    "เครื่องบินบินไปกรุงเทพ",
    "ธนาคารกลางประกาศปรับขึ้นอัตราดอกเบี้ย",
    "ปัญญาประดิษฐ์ประมวลผลภาษาไทย",
    "โทรศัพท์มือถือใช้งานง่าย",
    "ระบบประมวลผลภาษาธรรมชาติใช้เทคนิคการเรียนรู้เชิงลึก",
    "การพัฒนาปัญญาประดิษฐ์ต้องคำนึงถึงจริยธรรม",
    "รัฐบาลควรพัฒนาระบบขนส่งสาธารณะ",
    "ฉันกินข้าวกับเพื่อน",
    "บริษัทซีพีถือหุ้นเซเว่นอีเลฟเว่น",
    "นักลงทุนถือพันธบัตรรัฐบาลไทย",
]


# ============================================================================
# 8.  MAIN ANALYSIS FUNCTION  (returns structured dict)
# ============================================================================

def analyze(text: str, train_corpus: List[str] = None) -> dict:
    """
    Full analysis of a Thai string. Returns a JSON-serializable dict with:
      register, word_origins, compression levels, dual-mode tokens,
      template matches, multilingual bridges, and compression ratios.
    """
    if not HAS_PYTHAINLP:
        return {"error": "pythainlp not installed. Run: pip install pythainlp --break-system-packages"}

    corpus = (train_corpus or []) + SEED
    dual = DualModeTokenizer()
    dual.train(corpus)

    morph = thai_morpheme_tokenize(text)
    thai_only = [m for m in morph if is_thai(m)]
    try:
        tagged = pos_tag(morph, engine='perceptron', corpus='pud')
    except Exception:
        tagged = [(m, 'UNKN') for m in morph]

    content = content_only_tokenize(text)
    train_toks = dual.tokenize_train(text)
    infer_toks = dual.tokenize_infer(text)

    n_bpe = bpe_estimate(text)
    n_morph = len(train_toks)
    n_infer = len(infer_toks)
    n_content = len(content)
    thai_chars = sum(1 for c in text if is_thai(c))

    reg_label, reg_pcts = classify_register(morph)

    origins = []
    for tok, pos in tagged:
        if not is_thai(tok):
            continue
        orig, bridge = word_origin(tok)
        origins.append({
            "token": tok, "syllables": count_syllables(tok),
            "origin": orig, "bridge": bridge, "pos": pos,
        })

    matched = match_templates(thai_only)
    bridges = multilingual_bridge(morph)

    def ratio(a, b):
        return round(a / b, 2) if b else 0.0

    return {
        "input": text,
        "register": {"label": reg_label, "breakdown_pct": reg_pcts},
        "word_origins": origins,
        "compression": {
            "L0_char": thai_chars,
            "L1_morpheme_train": n_morph,
            "L2_compound_infer": n_infer,
            "bpe_gpt_estimate": n_bpe,
            "content_only": n_content,
            "ratios": {
                "bpe_to_morpheme": ratio(n_bpe, n_morph),
                "bpe_to_infer": ratio(n_bpe, n_infer),
                "bpe_to_content": ratio(n_bpe, n_content),
                "morpheme_to_infer": ratio(n_morph, n_infer),
                "char_to_content": ratio(thai_chars, n_content),
            },
        },
        "dual_mode": {
            "train_atomic": train_toks,
            "infer_merged": infer_toks,
            "compounds_applied": sorted(dual.learned_compounds & set(infer_toks)),
        },
        "templates_matched": [
            {"name": t.name, "semantic_type": t.semantic_type,
             "pattern": t.description} for t in matched
        ],
        "multilingual_bridges": bridges,
        "content_tokens": content,
    }


# ============================================================================
# 9.  CLI
# ============================================================================

def _print_human(r: dict):
    if "error" in r:
        print("ERROR:", r["error"])
        return
    print(f"\nINPUT: {r['input']}")
    print(f"\nREGISTER: {r['register']['label']}")
    for k, v in r['register']['breakdown_pct'].items():
        if v:
            print(f"  {k:<10} {v}%")

    print(f"\nWORD ORIGINS ({len(r['word_origins'])} Thai tokens):")
    print(f"  {'TOKEN':<16}{'SYL':>4}  {'ORIGIN':<18}{'BRIDGE':<16}POS")
    for o in r['word_origins']:
        print(f"  {o['token']:<16}{o['syllables']:>4}  {o['origin']:<18}{o['bridge']:<16}{o['pos']}")

    c = r['compression']
    print("\nCOMPRESSION LEVELS:")
    print(f"  L0 char (naive)        {c['L0_char']:>4}")
    print(f"  L1 morpheme (TRAIN)    {c['L1_morpheme_train']:>4}")
    print(f"  L2 compound (INFER)    {c['L2_compound_infer']:>4}")
    print(f"  BPE/GPT estimate       {c['bpe_gpt_estimate']:>4}")
    print(f"  content-only core      {c['content_only']:>4}")
    print("\nKEY RATIOS:")
    for k, v in c['ratios'].items():
        print(f"  {k:<22} {v}x")

    d = r['dual_mode']
    print(f"\nDUAL-MODE:")
    print(f"  TRAIN ({len(d['train_atomic'])}): {' '.join(d['train_atomic'])}")
    print(f"  INFER ({len(d['infer_merged'])}): {' '.join(d['infer_merged'])}")
    if d['compounds_applied']:
        print(f"  compounds merged: {', '.join(d['compounds_applied'])}")

    if r['templates_matched']:
        print("\nTEMPLATE MATCHES:")
        for t in r['templates_matched']:
            print(f"  [{t['semantic_type']}] {t['name']} -> {t['pattern']}")

    if r['multilingual_bridges']:
        print("\nMULTILINGUAL BRIDGES:")
        for lang, words in r['multilingual_bridges'].items():
            print(f"  {lang:<16} {', '.join(words)}")

    print(f"\nCONTENT CORE: [{' | '.join(r['content_tokens'])}]\n")


def main():
    p = argparse.ArgumentParser(description="Thai morpheme/compound tokenizer + compression analyzer")
    p.add_argument("text", nargs="?", help="Thai text to analyze")
    p.add_argument("--json", action="store_true", help="Output structured JSON")
    p.add_argument("--train-file", help="Path to newline-separated Thai corpus to prime the PMI merger")
    args = p.parse_args()

    if not HAS_PYTHAINLP:
        print(json.dumps({"error": "pythainlp not installed. Run: pip install pythainlp --break-system-packages"}))
        sys.exit(1)

    if not args.text:
        p.print_help()
        sys.exit(0)

    train_corpus = None
    if args.train_file:
        with open(args.train_file, encoding="utf-8") as f:
            train_corpus = [line.strip() for line in f if line.strip()]

    result = analyze(args.text, train_corpus=train_corpus)

    if args.json:
        print(json.dumps(result, ensure_ascii=False, indent=2))
    else:
        _print_human(result)


if __name__ == "__main__":
    main()
