---
name: thai-tokenizer
description: "Use this skill whenever the user wants to analyze, tokenize, segment, or compress Thai-language text at the morpheme or compound level. Triggers include: any request to break Thai text into morphemes or words, detect the origin of Thai vocabulary (native Thai vs Sanskrit/Pali vs English vs Chinese loanwords), classify a Thai sentence's register (formal/colloquial/technical), measure token-compression ratios for Thai (BPE vs morpheme vs compound vs content-only), demonstrate dual-mode tokenization (atomic morphemes for training vs merged compounds for inference), match Thai text against semantic query templates, or show which world languages a Thai sentence bridges to. Also use when the user references 'the Thai tokenizer', 'FINALFINAL', 'the Thai AI thesis tool', 'dual-mode tokenization', 'morpheme compression', or asks to run compression analysis on Thai. Do NOT use for general Thai translation, Thai-to-English translation, or casual Thai conversation — this is a linguistic analysis tool, not a translator."
license: Author's own work (JeN, 2026). Provided for the author's use.
---

# Thai morpheme tokenizer & compression analyzer

Analyzes Thai text at four levels of abstraction and reports morpheme
segmentation, word origin, register, and token-compression ratios. Built on
the "Thai AI language thesis" (JeN, 2026): Thai compounds are ~90-95%
semantically transparent, so a model can be trained on fine-grained morphemes
but run inference on merged compounds — the core dual-mode idea.

> Script paths below are relative to this skill's directory.

## First step: install the dependency

The engine needs `pythainlp`, which is **not** preinstalled. Always run this
first (it is a no-op if already present):

```bash
pip install pythainlp --break-system-packages -q
```

If the environment has no network access, tell the user the tokenizer cannot
run here and stop — do not fabricate segmentation by hand, because hand
segmentation will not match the `newmm` engine the ratios depend on.

## Running an analysis

Pick output mode by task:

| Task | Command |
|---|---|
| Quick human-readable analysis | `python scripts/thai_tokenizer.py "ข้อความภาษาไทย"` |
| Structured output for further processing | `python scripts/thai_tokenizer.py --json "ข้อความ"` |
| Prime the compound merger with a corpus first | `python scripts/thai_tokenizer.py --train-file corpus.txt "ข้อความ"` |

The `--json` form is preferred when the result feeds into anything else
(a table, a comparison, a downstream computation). Parse it as JSON — do not
regex the human-readable form.

You can also import it directly instead of shelling out:

```python
import sys; sys.path.insert(0, "scripts")
from thai_tokenizer import analyze
result = analyze("ตระกูลชินวัตรถือหุ้นอะไรบ้าง")
```

## Reading the output — what each section means

The analysis returns these fields. When explaining results to the user,
translate the numbers into plain meaning rather than dumping the raw dict.

- **register** — `FORMAL` (≥40% Sanskrit/Pali), `TECHNICAL` (≥30% English
  loanwords), `COLLOQUIAL` (≥70% native), or `MIXED`. This tells the user what
  kind of Thai they are looking at.

- **word_origins** — per-token origin across 5 layers: Native Thai,
  Sanskrit/Pali, English loan, Chinese loan, Hybrid compound. Each carries a
  "bridge" language showing which civilization the word links to. This is the
  multilingual-pivot claim in action.

- **compression** — five token counts for the same text:
  - `L0_char` — raw Thai codepoints (worst case for naive tokenizers)
  - `L1_morpheme_train` — dictionary morphemes (TRAIN mode)
  - `L2_compound_infer` — PMI-merged compounds (INFER mode)
  - `bpe_gpt_estimate` — approximate GPT-style BPE count for comparison
  - `content_only` — semantic core after stopword removal
  - plus **ratios** — the headline numbers. `bpe_to_content` around 4.7x and
    `bpe_to_morpheme` around 4.0x are the thesis's validated figures; expect
    results in that neighborhood for typical sentences.

- **dual_mode** — the same sentence shown as atomic morphemes (what the model
  trains on) vs merged compounds (what it runs inference on), plus which
  compounds were actually merged. Fewer infer tokens = fewer attention ops.

- **templates_matched** — if the sentence fits a known query shape
  (ownership, definition, location, causation, etc.), it is flagged. These are
  candidate O(1) fast-path patterns.

- **multilingual_bridges** — groups the sentence's loanwords by source
  language, illustrating Thai as a pivot that touches Sanskrit, English,
  Mandarin, etc. in a single sentence.

## Known behavior worth stating to the user

The `UNCUTTABLE` set lists multi-morpheme conjunctions and question words
(e.g. `ที่ไหน`). The `newmm` segmenter sometimes splits these into parts
(`ที่` + `ไหน`) *before* the per-token `UNCUTTABLE` check runs, so a fragment
like `ที่` can be dropped by the stopword filter even though the whole word was
meant to survive. This affects a small number of compound conjunctions and
slightly shifts content-token counts. It is left **as-is on purpose** so
compression ratios match the author's validated numbers. If the user asks to
fix it, the fix is to match `UNCUTTABLE` on a sliding window across morphemes
*before* tier filtering — offer this as a change, don't apply it silently,
since it will move the ratios.

## Dependencies

`pythainlp` (Thai NLP; install with `--break-system-packages`). Pure-Python;
no other system packages required.
